go run *.go
